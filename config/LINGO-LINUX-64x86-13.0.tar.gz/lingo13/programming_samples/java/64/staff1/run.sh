#! /bin/sh

rm Staff1.class
javac -classpath ../../../Lingo13.jar Staff1.java
java -classpath ../../../Lingo13.jar:./ Staff1
