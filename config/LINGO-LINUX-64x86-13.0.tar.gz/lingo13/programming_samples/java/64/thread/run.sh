#! /bin/sh

rm ThreadTest.class
rm RunAThread.class
javac -classpath ../../../Lingo13.jar ThreadEx.java
java -classpath ../../../Lingo13.jar:./ ThreadTest
