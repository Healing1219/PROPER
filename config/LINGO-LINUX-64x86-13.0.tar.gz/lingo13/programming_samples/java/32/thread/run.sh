#! /bin/sh

# ***** Be sure to set up symbolic links by running
# ***** symlinks.sh in the /lingo/bin/<PLATFORM> directory

rm ThreadTest.class
rm RunAThread.class
javac -classpath ../../../Lingo13.jar ThreadEx.java
java -classpath ../../../Lingo13.jar:./ ThreadTest
