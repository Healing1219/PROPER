#! /bin/sh

# ***** Be sure to set up symbolic links by running
# ***** symlinks.sh in the /lingo/bin/<PLATFORM> directory

rm Staff1.class
javac -classpath ../../../Lingo13.jar Staff1.java
java -classpath ../../../Lingo13.jar:./ Staff1
