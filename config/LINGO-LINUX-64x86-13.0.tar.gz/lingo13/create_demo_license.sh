#! /bin/sh

# This script creates and stores Lingo's license files for demo
# versions.  Demo versions work like regular versions, but their
# maximum model limits are restricted.  If you do not already
# have a valid license and you would like to create one, then you 
# need to run this script to copy the license files to the correct paths.
# You can run this script from the lingo13/license folder with the
# command-line command:  
#   
#    sh create_demo_license.sh

cp ./license/linux32/lndlng13_demo.lic ./license/linux32/lndlng13.lic -v
cp ./license/linux64/lndlng64_13_demo.lic ./license/linux64/lndlng13.lic -v

